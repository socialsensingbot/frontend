create definer = admin@`%` view view_live_regions_and_layers as
select `t`.`source_id`        AS `source_id`,
       `t`.`source`           AS `source`,
       `t`.`hazard`           AS `hazard`,
       `t`.`source_timestamp` AS `source_timestamp`,
       `lgm`.`layer_group_id` AS `layer_group_id`,
       `tr`.`region_type`     AS `region_type`,
       `tr`.`region`          AS `region`
from (((`socialsensing`.`live_text` `t` left join `socialsensing`.`live_text_regions` `tr` on ((
        (`tr`.`source_id` = `t`.`source_id`) and (`tr`.`source` = `t`.`source`) and
        (`tr`.`hazard` = `t`.`hazard`)))) join `socialsensing`.`ref_map_layer_groups_mapping` `lgm`)
         join `socialsensing`.`ref_map_layers` `l`)
where ((`t`.`source` = `l`.`source`) and (`t`.`hazard` = `l`.`hazard`) and (`l`.`id` = `lgm`.`layer_id`));

