create
    definer = admin@`%` procedure update_text_count(IN start_date date, IN end_date date)
BEGIN
    -- rollback transaction and bubble up errors if something bad happens
    DECLARE exit handler FOR SQLEXCEPTION, SQLWARNING
        BEGIN
            GET DIAGNOSTICS CONDITION 1
                @p1 = RETURNED_SQLSTATE, @p2 = MESSAGE_TEXT;
            ROLLBACK;
            set @rc = @p1;
            call debug_msg(-2, 'update_text_count', concat('FAILED: ', @p1, ': ', @p2));
        END;
    call debug_msg(0, 'update_text_count', CONCAT('Updating mat_view_text_count from ', start_date, ' to ', end_date));
    START TRANSACTION;
    DELETE FROM mat_view_text_count WHERE source_date BETWEEN start_date and end_date;

    # This zeros out all daily counts for ALL the days in the range. So that when the actual values are
    # placed in the table, any missing days (i.e. with no data) still get these zero values.
    INSERT INTO mat_view_text_count
    SELECT distinct 0    as text_count,
                    t.source,
                    t.hazard,
                    date as source_date,
                    t.region_type,
                    t.region,
                    t.warning,
                    t.deleted,
                    t.map_location
    FROM mat_view_map_criteria t,
         (select date from mat_view_days where date BETWEEN start_date and end_date) days;

    #Now replace all non-zero days.
    REPLACE INTO mat_view_text_count
    SELECT count(t.source)                                               as text_count,
           t.source,
           t.hazard,
           cast(date_format(t.source_timestamp, '%Y-%m-%d') as DATETIME) as source_date,
           t.region_type,
           t.region,
           t.warning,
           t.deleted,
           t.map_location
    FROM mat_view_regions t
    WHERE t.source_timestamp BETWEEN start_date and end_date
    GROUP BY region, region_type, hazard, source, t.map_location, warning, deleted, source_date;
    COMMIT;
    call debug_msg(0, 'update_text_count', CONCAT('Updated mat_view_text_count from ', start_date, ' to ', end_date));

END;

