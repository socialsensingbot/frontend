create definer = admin@`%` view view_geo_regions_with_virtual as
select distinct `gr`.`boundary`                                        AS `boundary`,
                ifnull(`ra`.`virtual_region`, `gr`.`region`)           AS `region`,
                `gr`.`map_location`                                    AS `map_location`,
                ifnull(`ra`.`virtual_region_type`, `gr`.`region_type`) AS `region_type`,
                `gr`.`title`                                           AS `title`,
                `gr`.`level`                                           AS `level`,
                `gr`.`centroid`                                        AS `centroid`,
                `gr`.`envelope`                                        AS `envelope`,
                `gr`.`buffered`                                        AS `buffered`,
                `gr`.`disabled`                                        AS `disabled`
from (`socialsensing`.`ref_geo_regions` `gr`
         join `socialsensing`.`ref_geo_virtual_regions` `ra`)
where ((`gr`.`region` = `ra`.`geo_region`) and (`ra`.`geo_region_type` = `gr`.`region_type`))
union
select `socialsensing`.`ref_geo_regions`.`boundary`     AS `boundary`,
       `socialsensing`.`ref_geo_regions`.`region`       AS `region`,
       `socialsensing`.`ref_geo_regions`.`map_location` AS `map_location`,
       `socialsensing`.`ref_geo_regions`.`region_type`  AS `region_type`,
       `socialsensing`.`ref_geo_regions`.`title`        AS `title`,
       `socialsensing`.`ref_geo_regions`.`level`        AS `level`,
       `socialsensing`.`ref_geo_regions`.`centroid`     AS `centroid`,
       `socialsensing`.`ref_geo_regions`.`envelope`     AS `envelope`,
       `socialsensing`.`ref_geo_regions`.`buffered`     AS `buffered`,
       `socialsensing`.`ref_geo_regions`.`disabled`     AS `disabled`
from `socialsensing`.`ref_geo_regions`;

