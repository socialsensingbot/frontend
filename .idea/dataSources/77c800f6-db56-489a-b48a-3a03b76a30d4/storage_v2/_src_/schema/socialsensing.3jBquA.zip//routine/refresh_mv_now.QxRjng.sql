create
    definer = admin@`%` procedure refresh_mv_now(OUT rc int)
BEGIN
    call debug_msg(2, 'refresh_mv_now', 'Refreshing (Latest) Materialized Views');

    call refresh_mv(DATE_SUB(NOW(), INTERVAL 1 HOUR), NOW(), @rc);
    START TRANSACTION;
    call fill_hours(DATE_SUB(NOW(), INTERVAL 1 HOUR), DATE_ADD(NOW(), INTERVAL 1 HOUR));
    call debug_msg(1, 'refresh_mv', 'Updated mat_view_hours');
    COMMIT;

    SET rc = 0;
END;

