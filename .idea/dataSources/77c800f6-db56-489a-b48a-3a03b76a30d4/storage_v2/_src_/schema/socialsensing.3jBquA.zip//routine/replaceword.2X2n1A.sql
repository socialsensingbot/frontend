create
    definer = admin@`%` function replaceword(str varchar(128), word varchar(128)) returns varchar(128) deterministic
BEGIN
    DECLARE loc INT;
    DECLARE punct CHAR(27) DEFAULT ' ()[]{},.-_!@;:?/''"#$%^&*<>';
    DECLARE lowerWord VARCHAR(128);
    DECLARE lowerStr VARCHAR(128);

    IF LENGTH(word) = 0 THEN
        RETURN str;
    END IF;
    SET lowerWord = LOWER(word);
    SET lowerStr = LOWER(str);
    SET loc = LOCATE(lowerWord, lowerStr, 1);
    WHILE loc > 0 DO
            IF loc = 1 OR LOCATE(SUBSTRING(str, loc-1, 1), punct) > 0 THEN
                IF loc+LENGTH(word) > LENGTH(str) OR LOCATE(SUBSTRING(str, loc+LENGTH(word), 1), punct) > 0 THEN
                    SET str = INSERT(str,loc,LENGTH(word),word);
                END IF;
            END IF;
            SET loc = LOCATE(lowerWord, lowerStr, loc+LENGTH(word));
        END WHILE;
    RETURN str;
END;

