create definer = admin@`%` event mv_latest_refresh_event on schedule
    every '5' MINUTE
        starts '2014-01-18 00:00:00'
    enable
    do
    CALL refresh_mv_now(@rc);

