create
    definer = admin@`%` procedure refresh_mv_auto(OUT rc int)
BEGIN

    -- rollback transaction and bubble up errors if something bad happens
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
        BEGIN
            GET DIAGNOSTICS CONDITION 1
                @p1 = RETURNED_SQLSTATE, @p2 = MESSAGE_TEXT;
            DO RELEASE_LOCK('internal_mv_refresh');
            call debug_msg(1, 'refresh_mv_auto', 'LOCK RELEASED');
            call debug_msg(-2, 'refresh_mv_auto', concat('FAILED: ', @p1, ': ', @p2));
            set @rc = @p1;
        END;

    SET TRANSACTION ISOLATION LEVEL READ COMMITTED;

    call debug_msg(1, 'refresh_mv_auto', 'STARTING');
    set @max_id = (select max(id) from internal_mv_refresh);
    call debug_msg(1, 'refresh_mv_auto', concat('This is iteration ', @max_id));
    IF GET_LOCK('internal_mv_refresh', 60) THEN
        call debug_msg(1, 'refresh_mv_auto', 'LOCK ACQUIRED');
        IF mod(@max_id, 12) = 1
        THEN
            call debug_msg(0, 'refresh_mv_auto', 'Selected WINDOW');
            call refresh_mv_map_window(@rc);
            call debug_msg(0, 'refresh_mv_auto', 'Completed WINDOW');
        ELSE
            call debug_msg(0, 'refresh_mv_auto', 'Selected NOW');
            call refresh_mv_now(@rc);
            call debug_msg(0, 'refresh_mv_auto', 'Completed NOW');
        END IF;
    ELSE
        call debug_msg(1, 'refresh_mv_auto', 'Already running.');
    END IF;

    START TRANSACTION;
    INSERT INTO internal_mv_refresh (time) values (now());
    COMMIT;
    call debug_msg(1, 'refresh_mv_auto', 'COMPLETED');
    DO RELEASE_LOCK('internal_mv_refresh');
    SET rc = 0;
END;

