create definer = admin@`%` event daily_housekeeping_event on schedule
    every '1' DAY
        starts '2021-01-01 04:17:17'
    enable
    do
    CALL daily_housekeeping(@rc);

