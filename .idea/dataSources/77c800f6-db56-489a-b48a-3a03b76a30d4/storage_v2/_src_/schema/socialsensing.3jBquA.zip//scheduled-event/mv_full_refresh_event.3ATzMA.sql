create definer = admin@`%` event mv_full_refresh_event on schedule
    every '1' DAY
        starts '2014-01-18 00:00:00'
    enable
    do
    CALL refresh_mv_full(@rc);

