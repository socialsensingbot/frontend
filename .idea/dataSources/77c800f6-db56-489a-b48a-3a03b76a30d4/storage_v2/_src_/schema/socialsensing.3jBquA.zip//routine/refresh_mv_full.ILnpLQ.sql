create
    definer = admin@`%` procedure refresh_mv_full(OUT rc int)
BEGIN
    call debug_msg(1, 'refresh_mv', 'Refreshing up untiil now()');
    CALL refresh_mv_full_until(NOW(), @rc);
END;

