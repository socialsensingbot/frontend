create
    definer = admin@`%` procedure refresh_mv_full(OUT rc int)
BEGIN


    DECLARE dt DATE DEFAULT '2017-01-01';
    call debug_msg(2, 'refresh_mv_full', 'Refreshing (Full) Materialized Views');


    call debug_msg(2, 'refresh_mv_full', 'Optimizing tables first');

    optimize table mat_view_timeseries_date;
    optimize table mat_view_timeseries_hour;
    optimize table mat_view_regions;
    optimize table mat_view_first_entries;
    optimize table mat_view_text_count;
    call debug_msg(2, 'refresh_mv_full', 'Optimized tables');

    START TRANSACTION;

    call debug_msg(2, 'refresh_mv_full', 'Refreshing map criteria.');

    # noinspection SqlWithoutWhere
    delete from mat_view_map_criteria;
    insert into mat_view_map_criteria
    SELECT distinct region,
                    region_type,
                    hazard,
                    source,
                    warning,
                    deleted,
                    map_location
    FROM mat_view_regions;
    call debug_msg(2, 'refresh_mv_full', 'Refreshed map criteria.');
    COMMIT;

    WHILE dt <= NOW()
        DO
            CALL refresh_mv(dt, DATE_ADD(dt, INTERVAL 1 MONTH), @rc);
            SET dt = DATE_ADD(dt, INTERVAL 1 MONTH);
        END WHILE;

    START TRANSACTION;

    call debug_msg(2, 'refresh_mv_full', 'Refreshing first entries.');

    REPLACE INTO mat_view_first_entries
    SELECT min(source_timestamp) as source_timestamp, hazard, source
    FROM mat_view_regions
    GROUP BY hazard, source;
    call debug_msg(2, 'refresh_mv_full', 'Refreshed first entries.');
    COMMIT;

    START TRANSACTION;
    call debug_msg(2, 'refresh_mv_full', 'Refreshing data day counts.');
    replace into mat_view_data_days
    select count(*) as days, region, region_type, hazard, source, warning
    from mat_view_text_count tc
    group by region, region_type, hazard, source, warning;
    call debug_msg(2, 'refresh_mv_full', 'Refreshed data day counts.');
    COMMIT;

    START TRANSACTION;
    call debug_msg(2, 'refresh_mv_full', 'Refreshing map criteria.');
    delete from mat_view_map_criteria;
    insert into mat_view_map_criteria
    SELECT distinct region,
                    region_type,
                    hazard,
                    source,
                    warning,
                    deleted,
                    map_location
    FROM mat_view_regions;
    call debug_msg(2, 'refresh_mv_full', 'Refreshed map criteria.');
    COMMIT;


    SET rc = 0;
END;

