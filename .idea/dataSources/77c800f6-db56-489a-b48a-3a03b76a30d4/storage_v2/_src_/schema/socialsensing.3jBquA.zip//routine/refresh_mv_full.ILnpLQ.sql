create
    definer = admin@`%` procedure refresh_mv_full(OUT rc int)
BEGIN

    DECLARE dt DATE DEFAULT '2017-01-01';
    declare counter int default 0;
    -- rollback transaction and bubble up errors if something bad happens
    DECLARE exit handler FOR SQLEXCEPTION, SQLWARNING
        BEGIN
            GET DIAGNOSTICS CONDITION 1
                @p1 = RETURNED_SQLSTATE, @p2 = MESSAGE_TEXT;
            ROLLBACK;
            set @rc = @p1;
            call debug_msg(-2, 'refresh_mv_full', concat('FAILED: ', @p1, ': ', @p2));
        END;

    call debug_msg(0, 'refresh_mv_full', 'Refreshing (Full) Materialized Views');

    START TRANSACTION;
    call debug_msg(1, 'refresh_mv_full', 'Refreshing map criteria.');
    # noinspection SqlWithoutWhere
    delete from mat_view_map_criteria;
    insert into mat_view_map_criteria
    SELECT distinct region,
                    region_type,
                    hazard,
                    source,
                    warning,
                    deleted,
                    map_location
    FROM mat_view_regions;
    call debug_msg(1, 'refresh_mv_full', 'Refreshed map criteria.');
    COMMIT;

    WHILE dt <= NOW()
        DO
            CALL debug_msg(1, 'refresh_mv_full', CONCAT('Refreshing week starting ', dt));
            CALL refresh_mv(dt, DATE_ADD(dt, INTERVAL 1 MONTH), @rc);
            CALL debug_msg(1, 'refresh_mv_full', CONCAT('Updating text count for week starting ', dt));
            CALL update_text_count(dt, DATE_ADD(dt, INTERVAL 1 MONTH));
            CALL debug_msg(1, 'refresh_mv_full', CONCAT('Filling days for week starting ', dt));
            CALL fill_days(dt, DATE_ADD(dt, INTERVAL 1 MONTH));
            CALL debug_msg(1, 'refresh_mv_full', CONCAT('Filling hours for week starting ', dt));
            CALL fill_hours(dt, DATE_ADD(dt, INTERVAL 1 MONTH));
            IF MOD(counter, 12) = 1
            THEN
                CALL refresh_mv_map_window(@rc);
            ELSE
                CALL refresh_mv_now(@rc);
            END IF;
            SET dt = DATE_ADD(dt, INTERVAL 1 MONTH);
            SET counter = counter + 1;
        END WHILE;

    START TRANSACTION;

    call debug_msg(1, 'refresh_mv_full', 'Refreshing first entries.');

    REPLACE INTO mat_view_first_entries
    SELECT min(source_timestamp) as source_timestamp, hazard, source
    FROM mat_view_regions
    GROUP BY hazard, source;
    call debug_msg(1, 'refresh_mv_full', 'Refreshed first entries.');
    COMMIT;

    START TRANSACTION;
    call debug_msg(1, 'refresh_mv_full', 'Refreshing data day counts.');
    replace into mat_view_data_days
    select datediff(max(source_date), min(source_date)) as days, region, region_type, hazard, source, warning
    from mat_view_text_count tc
    group by region, region_type, hazard, source, warning;
    call debug_msg(1, 'refresh_mv_full', 'Refreshed data day counts.');
    COMMIT;

    SET rc = 0;
END;

