create
    definer = admin@`%` procedure refresh_mv_map_window(OUT rc int)
BEGIN
    call debug_msg(2, 'refresh_mv_map_window', 'Refreshing (Window Duration) Materialized Views');

    call refresh_mv(DATE_SUB(NOW(), INTERVAL 4 DAY), DATE_ADD(NOW(), INTERVAL 1 DAY), @rc);

    START TRANSACTION;
    call fill_days(DATE_SUB(NOW(), INTERVAL 1 DAY), DATE_ADD(NOW(), INTERVAL 1 DAY));
    call debug_msg(1, 'refresh_mv', 'Updated mat_view_days');
    COMMIT;

    SET rc = 0;
END;

