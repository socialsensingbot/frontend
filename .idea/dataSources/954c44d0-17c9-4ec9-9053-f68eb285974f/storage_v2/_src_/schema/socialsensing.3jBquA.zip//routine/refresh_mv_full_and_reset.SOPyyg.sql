create
    definer = admin@`%` procedure refresh_mv_full_and_reset(OUT rc int)
BEGIN
    call debug_msg(1, 'refresh_mv_full_and_reset',
                   'Truncating tables mat_view_regions, mat_view_timeseries_date, mat_view_timeseries_hour');


    TRUNCATE mat_view_regions;
    TRUNCATE mat_view_timeseries_date;
    TRUNCATE mat_view_timeseries_hour;
    CALL refresh_mv_full(@rc);
END;

