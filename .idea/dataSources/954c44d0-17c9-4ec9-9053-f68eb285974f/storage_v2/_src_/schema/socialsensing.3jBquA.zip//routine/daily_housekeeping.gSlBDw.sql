create
    definer = admin@`%` procedure daily_housekeeping(IN opt int, OUT rc int)
BEGIN
    -- rollback transaction and bubble up errors if something bad happens
    DECLARE exit handler FOR SQLEXCEPTION, SQLWARNING
        BEGIN
            GET DIAGNOSTICS CONDITION 1
                @p1 = RETURNED_SQLSTATE, @p2 = MESSAGE_TEXT;
            ROLLBACK;
            set @rc = @p1;
            call debug_msg(-2, 'daily_housekeeping', concat('FAILED: ', @p1, ': ', @p2));
        END;

    call debug_msg(0, 'daily_housekeeping', 'Optimizing tables');
    IF opt = 1 THEN
        optimize table live_text;
        call debug_msg(1, 'daily_housekeeping', 'Optimized live_text.');
    ELSEIF opt = 2
    THEN
        optimize table mat_view_regions;
        call debug_msg(1, 'daily_housekeeping', 'Optimized mat_view_regions.');
    ELSEIF opt = 3
    THEN
        optimize table mat_view_timeseries_date;
        call debug_msg(1, 'daily_housekeeping', 'Optimized mat_view_timeseries_date.');
    ELSEIF opt = 4
    THEN
        optimize table mat_view_timeseries_hour;
        call debug_msg(1, 'daily_housekeeping', 'Optimized mat_view_timeseries_hour.');
    ELSEIF opt = 5
    THEN
        optimize table mat_view_first_entries;
        call debug_msg(1, 'daily_housekeeping', 'Optimized mat_view_first_entries.');

    ELSEIF opt = 6
    THEN
        optimize table mat_view_text_count;
        call debug_msg(1, 'daily_housekeeping', 'Optimized mat_view_text_count.');
    ELSEIF opt = 7
    THEN
        START TRANSACTION;
        call debug_msg(1, 'daily_housekeeping', 'Refreshing map criteria.');
        # noinspection SqlWithoutWhere
        delete from mat_view_map_criteria;
        insert into mat_view_map_criteria
        SELECT distinct region,
                        region_type,
                        hazard,
                        source,
                        warning,
                        deleted,
                        map_location,
                        language
        FROM mat_view_regions;
        call debug_msg(1, 'daily_housekeeping', 'Refreshed map criteria.');
        COMMIT;

    END IF;
    call debug_msg(0, 'daily_housekeeping', 'Optimized tables');

    START TRANSACTION;
    call debug_msg(1, 'daily_housekeeping', 'Refreshing data day counts.');
    replace into mat_view_data_days
    select datediff(max(source_date), min(source_date)) as days, region, region_type, hazard, source, warning, language
    from mat_view_text_count tc
    group by region, region_type, hazard, source, warning, language;
    call debug_msg(1, 'daily_housekeeping', 'Refreshed data day counts.');
    COMMIT;

    set @rc = 0;

END;

