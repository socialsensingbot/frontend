create
    definer = admin@`%` procedure refresh_mv(IN start_date datetime, IN end_date datetime, OUT rc int)
BEGIN

    -- rollback transaction and bubble up errors if something bad happens
    DECLARE exit handler FOR SQLEXCEPTION, SQLWARNING
        BEGIN
            GET DIAGNOSTICS CONDITION 1
                @p1 = RETURNED_SQLSTATE, @p2 = MESSAGE_TEXT;
            ROLLBACK;
            set @rc = @p1;
            call debug_msg(-2, 'refresh_mv', concat('FAILED: ', @p1, ': ', @p2));
        END;
    call debug_msg(0, 'refresh_mv', 'Refreshing Materialized Views');
    call debug_msg(1, 'refresh_mv', CONCAT('Start Date: ', start_date));
    call debug_msg(1, 'refresh_mv', CONCAT('End Date: ', end_date));
    SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
    START TRANSACTION;

    #     delete from mat_view_regions where source_timestamp < NOW() - INTERVAL 1 YEAR;

#     SET @maxTimestamp = IFNULL((select max(source_timestamp) from mat_view_regions), NOW() - INTERVAL 20 YEAR);
    call debug_msg(1, 'refresh_mv', 'Updating mat_view_regions');
    #     DELETE FROM mat_view_regions WHERE source_timestamp BETWEEN start_date and end_date;
#     call debug_msg(1, 'refresh_mv', 'Deleted old from mat_view_regions');

    # Put in the fine, coarse and county stats that Rudy generates data for (the old way of doing this)
    START TRANSACTION;
    REPLACE INTO mat_view_regions
    SELECT t.source_id,
           t.source,
           t.hazard,
           t.source_timestamp          source_timestamp,
           tr.region_type,
           tr.region,
           t.warning,
           IFNULL(t.deleted, false) as deleted,
           'uk',
           t.language
    FROM live_text t,
         live_text_regions tr
    WHERE t.source_id = tr.source_id
      AND t.source = tr.source
      AND t.hazard = tr.hazard
      AND t.source_timestamp BETWEEN start_date and end_date;
    COMMIT;
    call debug_msg(1, 'refresh_mv', 'Updated mat_view_regions with live_text_regions data.');

    # Add in all other regions (the new way of doing this)
    START TRANSACTION;
    REPLACE INTO mat_view_regions
    SELECT t.source_id,
           t.source,
           t.hazard,
           t.source_timestamp       as source_timestamp,
           gr.region_type,
           gr.region,
           t.warning,
           IFNULL(t.deleted, false) as deleted,
           gr.map_location,
           t.language
    FROM live_text t,
         ref_geo_regions gr
    WHERE t.source_timestamp BETWEEN start_date and end_date
      AND (select count(*)
           from live_text_regions tr
           WHERE t.source_id = tr.source_id
             AND t.source = tr.source
             AND t.hazard = tr.hazard) = 0
      AND ST_Intersects(boundary, location)
      AND NOT gr.disabled;
    COMMIT;
    call debug_msg(1, 'refresh_mv', 'Updated mat_view_regions with boundary matches.');

    #     START TRANSACTION;
#     REPLACE INTO mat_view_regions
#     SELECT t.source_id,
#            t.source,
#            t.hazard,
#            t.source_timestamp       as source_timestamp,
#            vr.virtual_region_type   as region_type,
#            vr.virtual_region        as region,
#            t.warning,
#            IFNULL(t.deleted, false) as deleted,
#            gr.map_location
#     FROM live_text t,
#          ref_geo_regions gr,
#          ref_geo_virtual_regions vr
#     WHERE ST_Intersects(boundary, location)
#       AND vr.geo_region = gr.region
#       AND vr.geo_region_type = gr.region_type
#       AND NOT gr.disabled
#       AND t.source_timestamp BETWEEN start_date and end_date;
#     COMMIT;
#     call debug_msg(1, 'refresh_mv', 'Updated mat_view_regions with virtual region boundary matches.');


    #     call debug_msg(1, 'refresh_mv', 'Fixing mat_view_regions for UK only');

    #     # UK Locations are buffered with a 0.01 degree buffer. At present this is not done on the world map

#     # If the world map is supported then this may be required to capture location just outside of the strict
#     # boundary supplied. We only use the buffered values when the non buffered regions do not match.
#     INSERT INTO mat_view_regions
#     SELECT t.source_id,
#            t.source,
#            t.hazard,
#            t.source_timestamp,
#            gr.region_type,
#            gr.region,
#            t.warning,
#            IFNULL(t.deleted, false) as deleted,
#            gr.map_location
#     FROM live_text t,
#          ref_geo_regions gr
#     WHERE ST_Intersects(buffered, location)
#       AND map_location = 'uk'
#       AND (select count(*) from ref_geo_regions where st_intersects(boundary, t.location) and map_location = 'uk') = 0
#       AND t.source_timestamp BETWEEN start_date and end_date;
    call debug_msg(1, 'refresh_mv', 'Updated mat_view_regions');


    START TRANSACTION;
    call debug_msg(1, 'refresh_mv', 'Updating mat_view_timeseries_date');

    #     SET @maxTimestampTSD = IFNULL((select max(source_date) from mat_view_timeseries_date), NOW() - INTERVAL 20 YEAR);
#     DELETE FROM mat_view_timeseries_date WHERE source_date BETWEEN start_date and end_date;
    REPLACE INTO mat_view_timeseries_date
    SELECT r.region                 as region_group_name,
           t.source                 as source,
           t.hazard                 as hazard,
           t.warning                as warning,
           t.source_date            as source_date,

           t.source_text            as source_text,
           r.region_type            as region_type,
           IFNULL(t.deleted, false) as deleted,
           t.source_id              as source_id,
           r.map_location,
           r.language
    FROM mat_view_regions r,
         live_text t
    WHERE t.source_id = r.source_id
      AND t.source = r.source
      AND t.hazard = r.hazard
      and not r.region REGEXP '^[0-9]+$'
      AND source_date BETWEEN start_date and end_date;
    call debug_msg(1, 'refresh_mv', 'Updated mat_view_timeseries_date');
    COMMIT;

    START TRANSACTION;
    call debug_msg(1, 'refresh_mv', 'Updating mat_view_timeseries_hour');

#     SET @maxTimestampTSH = IFNULL((select max(source_date) from mat_view_timeseries_hour), NOW() - INTERVAL 20 YEAR);
    DELETE FROM mat_view_timeseries_hour WHERE source_date BETWEEN start_date and end_date;
    REPLACE INTO mat_view_timeseries_hour
    SELECT r.region                                                         as region_group_name,
           t.source                                                         as source,
           t.hazard                                                         as hazard,
           t.warning                                                        as warning,
           cast(date_format(t.source_timestamp, '%Y-%m-%d %H') as DATETIME) as source_date,

           t.source_text                                                    as source_text,
           r.region_type                                                    as region_type,
           IFNULL(t.deleted, false)                                         as deleted,
           t.source_id                                                      as source_id,
           r.map_location,
           r.language
    FROM mat_view_regions r,
         live_text t
    WHERE t.source_id = r.source_id
      AND t.source = r.source
      AND t.hazard = r.hazard
      and not r.region REGEXP '^[0-9]+$'
      AND t.source_timestamp BETWEEN start_date and end_date;
    call debug_msg(1, 'refresh_mv', 'Updated mat_view_timeseries_hour');
    COMMIT;


    START TRANSACTION;
    call debug_msg(1, 'refresh_mv', 'Fixing XY swapped data');
    #This swaps XY on broken UK data, this is a temporary solution and should be removed.
    UPDATE live_text
    SET location = st_swapxy(location)
    WHERE NOT st_contains(ST_GeomFromText('POLYGON((65 -15, 40 -15, 40 5, 65 5, 65 -15))', 4326), location)
      AND source_date BETWEEN start_date and end_date;
    call debug_msg(1, 'refresh_mv', 'Fixed XY swapped data');
    COMMIT;

    call debug_msg(0, 'refresh_mv', 'SUCCESS');


    SET rc = 0;
END;

