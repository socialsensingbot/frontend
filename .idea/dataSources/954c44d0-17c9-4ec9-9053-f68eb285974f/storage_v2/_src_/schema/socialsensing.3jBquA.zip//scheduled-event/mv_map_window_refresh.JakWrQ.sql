create definer = admin@`%` event mv_map_window_refresh on schedule
    every '4' HOUR
        starts '2014-01-18 00:00:00'
    enable
    do
    CALL refresh_mv_map_window(@rc);

