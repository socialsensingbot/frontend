create definer = admin@`%` event mv_refresh_event on schedule
    every '5' MINUTE
        starts '2021-01-01 00:00:00'
    enable
    do
    CALL refresh_mv_auto(@rc);

