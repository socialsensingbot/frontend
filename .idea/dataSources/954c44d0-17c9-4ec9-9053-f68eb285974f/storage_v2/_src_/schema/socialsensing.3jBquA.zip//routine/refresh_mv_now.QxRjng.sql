create
    definer = admin@`%` procedure refresh_mv_now(OUT rc int)
BEGIN

    -- rollback transaction and bubble up errors if something bad happens
    DECLARE exit handler FOR SQLEXCEPTION, SQLWARNING
        BEGIN
            GET DIAGNOSTICS CONDITION 1
                @p1 = RETURNED_SQLSTATE, @p2 = MESSAGE_TEXT;
            ROLLBACK;
            set @rc = @p1;
            call debug_msg(-2, 'refresh_mv_now', concat('FAILED: ', @p1, ': ', @p2));
        END;
    call debug_msg(0, 'refresh_mv_now', 'Refreshing (Latest) Materialized Views');
    call refresh_mv(DATE_SUB(NOW(), INTERVAL 2 HOUR), NOW(), @rc);
    call fill_hours(DATE_SUB(NOW(), INTERVAL 1 DAY), DATE_ADD(NOW(), INTERVAL 1 DAY));
    call debug_msg(0, 'refresh_mv', 'Updated mat_view_hours');
    SET rc = 0;
END;

