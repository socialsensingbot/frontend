create definer = admin@`%` event daily_housekeeping_event_3 on schedule
    every '1' WEEK
        starts '2021-01-03 02:17:17'
    enable
    do
    CALL daily_housekeeping(3,@rc);

