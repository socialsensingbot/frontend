create
    definer = admin@`%` procedure daily_housekeeping(OUT rc int)
BEGIN
    -- rollback transaction and bubble up errors if something bad happens
    DECLARE exit handler FOR SQLEXCEPTION, SQLWARNING
        BEGIN
            GET DIAGNOSTICS CONDITION 1
                @p1 = RETURNED_SQLSTATE, @p2 = MESSAGE_TEXT;
            ROLLBACK;
            set @rc = @p1;
            call debug_msg(-2, 'daily_housekeeping', concat('FAILED: ', @p1, ': ', @p2));
        END;

    call debug_msg(0, 'daily_housekeeping', 'Optimizing tables');
    #     optimize table live_text;
#     optimize table mat_view_regions;
#     optimize table mat_view_timeseries_date;
#     optimize table mat_view_timeseries_hour;
#     optimize table mat_view_first_entries;
#     optimize table mat_view_text_count;
    call debug_msg(0, 'daily_housekeeping', 'Optimized tables');
    set @rc = 0;

END;

