create
    definer = admin@`%` procedure refresh_mv_full_until(IN end_date date, OUT rc int)
BEGIN

    DECLARE start_date DATE DEFAULT '2017-01-01';
    declare counter int default 0;
    -- rollback transaction and bubble up errors if something bad happens
    DECLARE exit handler FOR SQLEXCEPTION, SQLWARNING
        BEGIN
            GET DIAGNOSTICS CONDITION 1
                @p1 = RETURNED_SQLSTATE, @p2 = MESSAGE_TEXT;
            DO RELEASE_LOCK('internal_mv_refresh');
            call debug_msg(1, 'refresh_mv_full', 'LOCK RELEASED');
            ALTER EVENT mv_refresh_event enable;
            ROLLBACK;
            set @rc = @p1;
            call debug_msg(-2, 'refresh_mv_full', concat('FAILED: ', @p1, ': ', @p2));
        END;

    call debug_msg(0, 'refresh_mv_full', 'Refreshing (Full) Materialized Views');
    IF GET_LOCK('internal_mv_refresh', 60) THEN
        call debug_msg(1, 'refresh_mv_full', 'LOCK ACQUIRED');
        ALTER EVENT mv_refresh_event disable;
        SET TRANSACTION ISOLATION LEVEL READ COMMITTED;


        WHILE end_date >= start_date
            DO
                CALL debug_msg(1, 'refresh_mv_full', CONCAT('Refreshing month ending ', end_date));
                CALL refresh_mv(DATE_SUB(end_date, INTERVAL 1 MONTH), end_date, @rc);
                CALL debug_msg(1, 'refresh_mv_full', CONCAT('Updating text count for month ending ', end_date));
                CALL update_text_count(DATE_SUB(end_date, INTERVAL 1 MONTH), end_date);
                CALL debug_msg(1, 'refresh_mv_full', CONCAT('Filling days for month ending ', end_date));
                CALL fill_days(DATE_SUB(end_date, INTERVAL 1 MONTH), end_date);
                CALL debug_msg(1, 'refresh_mv_full', CONCAT('Filling hours for month ending ', end_date));
                CALL fill_hours(DATE_SUB(end_date, INTERVAL 1 MONTH), end_date);
                #             IF MOD(counter, 12) = 1
#             THEN
#                 CALL refresh_mv_map_window(@rc);
#             ELSE
#                 CALL refresh_mv_now(@rc);
#             END IF;
                SET end_date = DATE_SUB(end_date, INTERVAL 1 MONTH);
                SET counter = counter + 1;
            END WHILE;

        call debug_msg(1, 'refresh_mv_full', 'Refreshing first entries.');

        START TRANSACTION;
        REPLACE INTO mat_view_first_entries
        SELECT min(source_timestamp) as source_timestamp, hazard, source
        FROM mat_view_regions
        GROUP BY hazard, source;
        call debug_msg(1, 'refresh_mv_full', 'Refreshed first entries.');
        COMMIT;

        START TRANSACTION;
        call debug_msg(1, 'refresh_mv_full', 'Refreshing data day counts.');
        replace into mat_view_data_days
        select datediff(max(source_date), min(source_date)) as days,
               region,
               region_type,
               hazard,
               source,
               warning,
               language
        from mat_view_text_count tc
        group by region, region_type, hazard, source, warning;
        call debug_msg(1, 'refresh_mv_full', 'Refreshed data day counts.');
        COMMIT;


        ALTER EVENT mv_refresh_event enable;
        DO RELEASE_LOCK('internal_mv_refresh');
    ELSE
        call debug_msg(1, 'refresh_mv_full', 'Already running.');
    END IF;
    COMMIT;
    SET rc = 0;
END;

