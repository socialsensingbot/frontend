create definer = admin@`%` event daily_housekeeping_event_1 on schedule
    every '1' WEEK
        starts '2021-01-01 02:17:17'
    enable
    do
    CALL daily_housekeeping(1,@rc);

