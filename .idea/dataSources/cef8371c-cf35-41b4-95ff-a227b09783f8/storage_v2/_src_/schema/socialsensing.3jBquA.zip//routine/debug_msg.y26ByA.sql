create
    definer = admin@`%` procedure debug_msg(IN level int, IN source varchar(32), IN message text)
BEGIN
    INSERT INTO internal_debug (time, level, message, source) VALUES (NOW(), level, message, source);
END;

