create definer = admin@`%` event daily_housekeeping_event_6 on schedule
    every '1' WEEK
        starts '2021-01-06 02:17:17'
    enable
    do
    CALL daily_housekeeping(6,@rc);

